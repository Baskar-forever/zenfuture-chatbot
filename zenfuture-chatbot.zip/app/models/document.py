from dataclasses import dataclass, field

@dataclass(slots=True)
class Document:
    url: str
    title: str
    content: str
    source: str = "website"
    metadata: dict = field(default_factory=dict)
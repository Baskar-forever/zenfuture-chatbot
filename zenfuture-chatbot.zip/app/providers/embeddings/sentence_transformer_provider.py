from sentence_transformers import SentenceTransformer

from app.providers.embeddings.base import EmbeddingProvider


class SentenceTransformerProvider(
    EmbeddingProvider
):

    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)

    def embed_text(self, text: str):
        return self.model.encode(text).tolist()

    def embed_batch(self, texts: list[str]):
        return self.model.encode(texts).tolist()